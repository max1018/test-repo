# GMP-100 Real-Footage Gate 1A

This branch runs a strict, duration-proportional codec gate on 60 seconds of the openly licensed *Tears of Steel* film.

The test compares:

1. All available visual bytes invested in the structural AV1 stream.
2. A lower-rate structural AV1 stream plus a deterministic optical-flow temporal residual atlas.

The atlas receives no free capacity. Its bytes are deducted from the structural stream, and it survives only if the completed candidate package is no larger while improving mean PSNR and SSIM without material temporal or tail-quality regression.

This is a 1080p SDR photorealistic proxy. It is not the native 4K HDR/PQ gate and does not claim that a 143-minute film under 100 MB is solved.

Source attribution: *Tears of Steel* — (CC) Blender Foundation | mango.blender.org — CC BY 3.0.
