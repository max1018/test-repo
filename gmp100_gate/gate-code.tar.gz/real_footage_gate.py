from __future__ import annotations

import argparse
import dataclasses
import gc
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Any, Iterable, Sequence

import cv2
import numpy as np
from skimage.metrics import structural_similarity

from temporal_atlas import apply_temporal_atlas, encode_temporal_atlas, frame_sequence_hash

FEATURE_SECONDS = 143 * 60
FEATURE_CAP_BYTES = 100_000_000
DEFAULT_DURATION = 60.0
DEFAULT_START = 480.0
DEFAULT_AUDIO_KBPS = 16.0
METRIC_WIDTH = 384
METRIC_FPS = 24.0
SOURCE_URL = "https://archive.org/download/Tears-of-Steel/tears_of_steel_1080p.mp4"
SOURCE_ATTRIBUTION = "Tears of Steel — (CC) Blender Foundation | mango.blender.org — CC BY 3.0"


class GateError(RuntimeError):
    pass


def log(message: str) -> None:
    print(f"[GMP-GATE] {message}", file=sys.stderr, flush=True)


@dataclasses.dataclass(frozen=True)
class Budget:
    duration_seconds: float
    proxy_cap_bytes: int
    audio_target_bytes: int
    container_reserve_bytes: int
    controls_reserve_bytes: int
    exact_exception_reserve_bytes: int
    atlas_reserve_bytes: int
    all_structural_visual_bytes: int
    atlas_structural_bytes: int

    def to_dict(self) -> dict[str, Any]:
        payload = dataclasses.asdict(self)
        payload["aggregate_kbps"] = self.proxy_cap_bytes * 8 / self.duration_seconds / 1000
        payload["all_structural_video_kbps"] = (
            self.all_structural_visual_bytes * 8 / self.duration_seconds / 1000
        )
        payload["atlas_candidate_video_kbps"] = (
            self.atlas_structural_bytes * 8 / self.duration_seconds / 1000
        )
        return payload


def run(command: Sequence[str], *, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        [str(x) for x in command],
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if check and result.returncode != 0:
        raise GateError(
            f"command failed ({result.returncode}): {' '.join(map(str, command))}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def ffprobe(path: Path) -> dict[str, Any]:
    result = run([
        "ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)
    ])
    return json.loads(result.stdout)


def video_stream(probe: dict[str, Any]) -> dict[str, Any]:
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "video":
            return stream
    raise GateError("video stream not found")


def duration_seconds(probe: dict[str, Any]) -> float:
    value = probe.get("format", {}).get("duration")
    if value is not None:
        return float(value)
    values = [float(s["duration"]) for s in probe.get("streams", []) if s.get("duration")]
    if not values:
        raise GateError("duration unavailable")
    return max(values)


def parse_rate(value: str | None) -> float:
    if not value or value == "0/0":
        return 0.0
    if "/" in value:
        n, d = value.split("/", 1)
        return float(n) / float(d)
    return float(value)


def even(value: float) -> int:
    rounded = max(2, int(round(value)))
    return rounded if rounded % 2 == 0 else rounded + 1


def compute_budget(duration: float, *, cap_scale: float = 1.0) -> Budget:
    if cap_scale <= 0:
        raise GateError("cap_scale must be positive")
    cap = math.floor(FEATURE_CAP_BYTES * cap_scale * duration / FEATURE_SECONDS)
    audio = math.ceil(DEFAULT_AUDIO_KBPS * 1000 * duration / 8)
    container = round(cap * 0.01)
    controls = round(cap * 0.01)
    exceptions = round(cap * 0.005)
    atlas = round(cap * 0.025)
    visual = cap - audio - container - controls - exceptions
    atlas_visual = visual - atlas
    if atlas_visual <= 0:
        raise GateError("proxy budget leaves no video bytes")
    return Budget(
        duration_seconds=duration,
        proxy_cap_bytes=cap,
        audio_target_bytes=audio,
        container_reserve_bytes=container,
        controls_reserve_bytes=controls,
        exact_exception_reserve_bytes=exceptions,
        atlas_reserve_bytes=atlas,
        all_structural_visual_bytes=visual,
        atlas_structural_bytes=atlas_visual,
    )


def trim_source(source: Path, output: Path, *, start: float, duration: float) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    # Re-encode losslessly enough for deterministic, frame-accurate extraction. The downloaded
    # source is already compressed; CRF 8 avoids compounding visible damage at the metric scale.
    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-ss", f"{start:.3f}", "-t", f"{duration:.3f}", "-i", str(source),
        "-map", "0:v:0", "-map", "0:a:0?",
        "-c:v", "libx264", "-preset", "medium", "-crf", "8", "-pix_fmt", "yuv420p",
        "-c:a", "flac", "-avoid_negative_ts", "make_zero", str(output),
    ])
    return output


def detect_av1_encoder() -> str:
    encoders = run(["ffmpeg", "-hide_banner", "-encoders"]).stdout
    if "libsvtav1" in encoders:
        return "libsvtav1"
    if "libaom-av1" in encoders:
        return "libaom-av1"
    raise GateError("neither libsvtav1 nor libaom-av1 is available")


def encode_av1_once(
    source: Path,
    output: Path,
    *,
    width: int,
    height: int,
    fps: float,
    kbps: float,
    encoder: str,
) -> None:
    if encoder == "libsvtav1":
        codec = [
            "-c:v", "libsvtav1", "-preset", "11", "-b:v", f"{max(1.0, kbps):.3f}k",
            "-svtav1-params", "rc=1:tune=0",
        ]
    else:
        codec = [
            "-c:v", "libaom-av1", "-cpu-used", "8", "-row-mt", "1",
            "-b:v", f"{max(1.0, kbps):.3f}k",
        ]
    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(source),
        "-map", "0:v:0", "-an",
        "-vf", f"fps={fps:.8f},scale={width}:{height}:flags=lanczos",
        *codec,
        "-g", str(max(48, round(fps * 4))), "-pix_fmt", "yuv420p10le", str(output),
    ])


def encode_to_target(
    source: Path,
    output: Path,
    *,
    width: int,
    height: int,
    fps: float,
    target_bytes: int,
    encoder: str,
    attempts: int = 3,
) -> dict[str, Any]:
    duration = duration_seconds(ffprobe(source))
    requested = max(1.0, target_bytes * 8 / duration / 1000 * 0.88)
    records: list[dict[str, Any]] = []
    best: tuple[int, Path, float] | None = None
    output.parent.mkdir(parents=True, exist_ok=True)
    for index in range(attempts):
        attempt = output.with_name(f"{output.stem}.attempt-{index}{output.suffix}")
        encode_av1_once(
            source, attempt, width=width, height=height, fps=fps, kbps=requested, encoder=encoder
        )
        actual = attempt.stat().st_size
        records.append({"attempt": index, "requested_kbps": requested, "actual_bytes": actual})
        if actual <= target_bytes and (best is None or actual > best[0]):
            best = (actual, attempt, requested)
        ratio = target_bytes / max(actual, 1)
        if actual <= target_bytes and ratio < 1.035:
            break
        if actual > target_bytes:
            requested *= max(0.25, min(0.90, ratio * 0.90))
        else:
            requested *= max(1.04, min(1.65, ratio * 0.96))
    if best is None:
        emitted = sorted(output.parent.glob(f"{output.stem}.attempt-*{output.suffix}"), key=lambda p: p.stat().st_size)
        smallest = emitted[0].stat().st_size if emitted else None
        raise GateError(f"no AV1 encode fit target {target_bytes:,}; smallest={smallest}")
    actual, selected, selected_kbps = best
    shutil.copy2(selected, output)
    for path in output.parent.glob(f"{output.stem}.attempt-*{output.suffix}"):
        path.unlink(missing_ok=True)
    return {
        "path": str(output), "width": width, "height": height, "fps": fps,
        "target_bytes": target_bytes, "actual_bytes": actual,
        "requested_kbps": selected_kbps, "attempts": records, "sha256": sha256(output),
    }


def encode_audio(source: Path, output: Path) -> dict[str, Any]:
    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(source),
        "-map", "0:a:0?", "-vn", "-ac", "2", "-ar", "48000",
        "-c:a", "libopus", "-b:a", f"{DEFAULT_AUDIO_KBPS:.0f}k", "-vbr", "off",
        "-application", "audio", str(output),
    ])
    return {"path": str(output), "bytes": output.stat().st_size, "sha256": sha256(output)}


def read_frames(
    path: Path,
    *,
    raw_path: Path,
    width: int = METRIC_WIDTH,
    fps: float = METRIC_FPS,
) -> np.memmap:
    """Decode once with FFmpeg to deterministic BGR24 raw frames, then memory-map them.

    OpenCV's direct HEVC/AV1 path can be extremely slow or inconsistent on hosted runners.
    A raw proxy makes the metric and optical-flow passes repeatable.
    """
    probe = ffprobe(path)
    stream = video_stream(probe)
    source_width = int(stream["width"])
    source_height = int(stream["height"])
    height = even(width * source_height / source_width)
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(path),
        "-map", "0:v:0", "-an",
        "-vf", f"fps={fps:.8f},scale={width}:{height}:flags=lanczos",
        "-f", "rawvideo", "-pix_fmt", "bgr24", str(raw_path),
    ])
    frame_bytes = width * height * 3
    size = raw_path.stat().st_size
    if size < frame_bytes or size % frame_bytes:
        raise GateError(
            f"invalid raw proxy size for {path}: {size:,} bytes, frame={frame_bytes:,}"
        )
    count = size // frame_bytes
    return np.memmap(raw_path, dtype=np.uint8, mode="r", shape=(count, height, width, 3))

def align(reference: Sequence[np.ndarray], candidate: Sequence[np.ndarray]) -> tuple[list[np.ndarray], list[np.ndarray]]:
    count = min(len(reference), len(candidate))
    if count < 12:
        raise GateError(f"too few aligned frames: {count}")
    return reference[:count], candidate[:count]


def luma(frame: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def edge_correlation(reference: np.ndarray, candidate: np.ndarray) -> float:
    ref = luma(reference).astype(np.float32)
    cand = luma(candidate).astype(np.float32)
    ref_edge = cv2.magnitude(cv2.Sobel(ref, cv2.CV_32F, 1, 0), cv2.Sobel(ref, cv2.CV_32F, 0, 1))
    cand_edge = cv2.magnitude(cv2.Sobel(cand, cv2.CV_32F, 1, 0), cv2.Sobel(cand, cv2.CV_32F, 0, 1))
    a = ref_edge.ravel()
    b = cand_edge.ravel()
    if float(np.std(a)) < 1e-6 or float(np.std(b)) < 1e-6:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def duplicate_rate(frames: Sequence[np.ndarray]) -> float:
    if len(frames) < 2:
        return 0.0
    duplicates = sum(
        1 for previous, current in zip(frames[:-1], frames[1:])
        if np.array_equal(previous, current)
    )
    return duplicates / (len(frames) - 1)


def temporal_delta_mae(reference: Sequence[np.ndarray], candidate: Sequence[np.ndarray]) -> float:
    values = []
    for ref_prev, ref_now, cand_prev, cand_now in zip(reference[:-1], reference[1:], candidate[:-1], candidate[1:]):
        ref_delta = luma(ref_now).astype(np.float32) - luma(ref_prev).astype(np.float32)
        cand_delta = luma(cand_now).astype(np.float32) - luma(cand_prev).astype(np.float32)
        values.append(float(np.mean(np.abs(ref_delta - cand_delta))))
    return float(np.mean(values)) if values else 0.0


def flow_delta(reference: Sequence[np.ndarray], candidate: Sequence[np.ndarray], *, step: int = 24) -> float:
    values: list[float] = []
    for index in range(step, min(len(reference), len(candidate)), step):
        ref0 = cv2.resize(luma(reference[index - 1]), (240, even(reference[index - 1].shape[0] * 240 / reference[index - 1].shape[1])))
        ref1 = cv2.resize(luma(reference[index]), (ref0.shape[1], ref0.shape[0]))
        can0 = cv2.resize(luma(candidate[index - 1]), (ref0.shape[1], ref0.shape[0]))
        can1 = cv2.resize(luma(candidate[index]), (ref0.shape[1], ref0.shape[0]))
        rf = cv2.calcOpticalFlowFarneback(ref0, ref1, None, 0.5, 3, 15, 3, 5, 1.1, 0)
        cf = cv2.calcOpticalFlowFarneback(can0, can1, None, 0.5, 3, 15, 3, 5, 1.1, 0)
        values.append(float(np.mean(np.linalg.norm(rf - cf, axis=2))))
    return float(np.mean(values)) if values else 0.0


def metrics(reference: Sequence[np.ndarray], candidate: Sequence[np.ndarray]) -> dict[str, Any]:
    ref, cand = align(reference, candidate)
    psnr: list[float] = []
    ssim: list[float] = []
    edges: list[float] = []
    sampled_indices = list(range(0, len(ref), 4))
    for index in sampled_indices:
        r = ref[index]
        c = cand[index]
        psnr.append(float(cv2.PSNR(r, c)))
        # Windowed SSIM and edge correlation are measured on a deterministic half-size proxy.
        eval_width = 192
        eval_height = even(r.shape[0] * eval_width / r.shape[1])
        ry = cv2.resize(luma(r), (eval_width, eval_height), interpolation=cv2.INTER_AREA)
        cy = cv2.resize(luma(c), (eval_width, eval_height), interpolation=cv2.INTER_AREA)
        ssim.append(float(structural_similarity(ry, cy, data_range=255)))
        r_small = cv2.cvtColor(cv2.resize(r, (eval_width, eval_height), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        c_small = cv2.cvtColor(cv2.resize(c, (eval_width, eval_height), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        edges.append(edge_correlation(r_small, c_small))
    return {
        "frame_count": len(ref),
        "sampled_metric_frames": len(sampled_indices),
        "metric_stride": 4,
        "mean_psnr_db": float(np.mean(psnr)),
        "worst_psnr_db": float(np.min(psnr)),
        "p05_psnr_db": float(np.percentile(psnr, 5)),
        "mean_ssim": float(np.mean(ssim)),
        "worst_ssim": float(np.min(ssim)),
        "p05_ssim": float(np.percentile(ssim, 5)),
        "mean_edge_correlation": float(np.mean(edges)),
        "duplicate_frame_rate": duplicate_rate(cand),
        "temporal_delta_mae": temporal_delta_mae(ref[::2], cand[::2]),
        "flow_delta": flow_delta(ref, cand, step=48),
    }

def build_atlas_adaptive(
    source_frames: Sequence[np.ndarray],
    base_frames: Sequence[np.ndarray],
    output_dir: Path,
    *,
    budget_bytes: int,
) -> dict[str, Any]:
    height, width = source_frames[0].shape[:2]
    trials = [
        (12, 160), (10, 152), (10, 144), (8, 136), (8, 128), (6, 120), (6, 112)
    ]
    errors: list[str] = []
    for anchors, map_width in trials:
        if output_dir.exists():
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        map_height = even(map_width * height / width)
        try:
            manifest = encode_temporal_atlas(
                source_frames,
                base_frames,
                output_dir,
                budget_bytes=budget_bytes,
                anchor_count=anchors,
                map_width=map_width,
                map_height=map_height,
                quantization_step=1.0,
                residual_clip=64.0,
                temporal_radius=96,
            )
            total = (output_dir / "temporal-atlas.webp").stat().st_size + (output_dir / "temporal-atlas.json").stat().st_size
            if total <= budget_bytes:
                return {"manifest": manifest.as_dict(), "total_sidecar_bytes": total, "trials": errors}
            errors.append(f"anchors={anchors}, width={map_width}: total {total} > {budget_bytes}")
        except Exception as exc:
            errors.append(f"anchors={anchors}, width={map_width}: {exc!r}")
    raise GateError("no temporal atlas fit sidecar budget: " + "; ".join(errors))


def package(
    output: Path,
    *,
    base: Path,
    audio: Path,
    sidecars: Sequence[Path],
    metadata: dict[str, Any],
    cap_bytes: int,
) -> dict[str, Any]:
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = dict(metadata)
    manifest["assets"] = []
    assets = [("streams/base.mkv", base), ("streams/audio.opus", audio)]
    assets.extend((f"sidecars/{path.name}", path) for path in sidecars)
    for name, path in assets:
        manifest["assets"].append({"path": name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, separators=(",", ":"), sort_keys=True))
        for name, path in assets:
            archive.write(path, name)
    result = {
        "path": str(output), "bytes": output.stat().st_size, "cap_bytes": cap_bytes,
        "headroom_bytes": cap_bytes - output.stat().st_size,
        "cap_pass": output.stat().st_size <= cap_bytes, "sha256": sha256(output),
        "payload_bytes": sum(path.stat().st_size for _, path in assets),
    }
    return result


def write_contact_sheet(
    reference: Sequence[np.ndarray], baseline: Sequence[np.ndarray], restored: Sequence[np.ndarray], output: Path
) -> None:
    count = min(len(reference), len(baseline), len(restored))
    picks = [0, count // 4, count // 2, (3 * count) // 4, count - 1]
    frame_h, frame_w = reference[0].shape[:2]
    label_h = 30
    canvas = np.full((3 * (frame_h + label_h), len(picks) * frame_w, 3), 18, np.uint8)
    rows = [("SOURCE", reference), ("ALL STRUCTURAL", baseline), ("STRUCTURAL + ATLAS", restored)]
    for row, (label, frames) in enumerate(rows):
        y = row * (frame_h + label_h)
        cv2.putText(canvas, label, (8, y + 21), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (245, 245, 245), 1, cv2.LINE_AA)
        for col, index in enumerate(picks):
            x = col * frame_w
            canvas[y + label_h:y + label_h + frame_h, x:x + frame_w] = frames[index]
            cv2.putText(canvas, f"f{index}", (x + 8, y + label_h + frame_h - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(str(output), canvas)


def write_preview(
    reference: Sequence[np.ndarray], baseline: Sequence[np.ndarray], restored: Sequence[np.ndarray], output: Path, *, seconds: int = 10
) -> None:
    count = min(len(reference), len(baseline), len(restored), seconds * int(METRIC_FPS))
    height, width = reference[0].shape[:2]
    temp = output.with_suffix(".avi")
    writer = cv2.VideoWriter(str(temp), cv2.VideoWriter_fourcc(*"MJPG"), METRIC_FPS, (width * 3, height + 28))
    if not writer.isOpened():
        raise GateError("cannot create preview video")
    for index in range(count):
        canvas = np.full((height + 28, width * 3, 3), 15, np.uint8)
        canvas[28:, 0:width] = reference[index]
        canvas[28:, width:2 * width] = baseline[index]
        canvas[28:, 2 * width:3 * width] = restored[index]
        for x, label in ((6, "SOURCE"), (width + 6, "ALL STRUCTURAL"), (2 * width + 6, "STRUCTURAL + ATLAS")):
            cv2.putText(canvas, label, (x, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (245, 245, 245), 1, cv2.LINE_AA)
        writer.write(canvas)
    writer.release()
    run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(temp),
        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", str(output),
    ])
    temp.unlink(missing_ok=True)


def report_markdown(result: dict[str, Any]) -> str:
    b = result["budget"]
    base = result["baseline"]["metrics"]
    atlas = result["atlas_candidate"]["metrics"]
    delta = result["decision"]["delta"]
    accepted = result["decision"]["accepted"]
    return f"""# GMP-100 Real-Footage Gate 1A

## Verdict

**{'PASS — retain the temporal atlas for the next tier' if accepted else 'FAIL — return atlas bytes to the structural stream'}**

This is a 60-second photorealistic **1080p SDR proxy**, not the final native-4K HDR gate. It uses *Tears of Steel*, an openly licensed live-action/CGI film, to expose failures that synthetic footage hides.

## Exact proportional budget

| Field | Bytes |
|---|---:|
| 143-minute feature ceiling | 100,000,000 |
| This clip's proportional ceiling | {b['proxy_cap_bytes']:,} |
| 16 kb/s audio target | {b['audio_target_bytes']:,} |
| All-structural visual pool | {b['all_structural_visual_bytes']:,} |
| Atlas reserve | {b['atlas_reserve_bytes']:,} |
| Atlas candidate structural pool | {b['atlas_structural_bytes']:,} |

## Equal-byte result

| Metric | All structural | Structural + atlas | Delta |
|---|---:|---:|---:|
| Mean PSNR | {base['mean_psnr_db']:.3f} dB | {atlas['mean_psnr_db']:.3f} dB | {delta['mean_psnr_db']:+.3f} dB |
| Mean SSIM | {base['mean_ssim']:.6f} | {atlas['mean_ssim']:.6f} | {delta['mean_ssim']:+.6f} |
| 5th percentile SSIM | {base['p05_ssim']:.6f} | {atlas['p05_ssim']:.6f} | {delta['p05_ssim']:+.6f} |
| Edge correlation | {base['mean_edge_correlation']:.6f} | {atlas['mean_edge_correlation']:.6f} | {delta['mean_edge_correlation']:+.6f} |
| Temporal-delta MAE (lower is better) | {base['temporal_delta_mae']:.4f} | {atlas['temporal_delta_mae']:.4f} | {delta['temporal_delta_mae']:+.4f} |
| Flow delta (lower is better) | {base['flow_delta']:.4f} | {atlas['flow_delta']:.4f} | {delta['flow_delta']:+.4f} |

## Retention conditions

- Candidate completed package must not exceed its cap.
- Candidate payload must not exceed the baseline payload.
- Mean PSNR and SSIM must both improve.
- Fifth-percentile SSIM may not materially regress.
- Temporal-delta error may not increase by more than 2%.
- Two independent atlas decodes must produce the same frame hash.

## Scope limits

- Source is 1080p SDR; 4K/PQ behavior is not established here.
- This CPU gate does not include a learned temporal model.
- OCR, face identity, articulated topology, and blind human preference remain mandatory downstream gates.

## Source

{SOURCE_ATTRIBUTION}

Source URL: `{SOURCE_URL}`
"""


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="GMP-100 real-footage equal-byte gate")
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--start", type=float, default=DEFAULT_START)
    parser.add_argument("--duration", type=float, default=DEFAULT_DURATION)
    parser.add_argument("--cap-scale", type=float, default=1.0, help="test-only multiplier; production gate uses 1.0")
    args = parser.parse_args(argv)

    started = time.time()
    out = args.output_dir.resolve()
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    work = out / "work"
    work.mkdir()

    log("trimming source segment")
    source_segment = trim_source(args.source.resolve(), work / "gate-source.mkv", start=args.start, duration=args.duration)
    source_probe = ffprobe(source_segment)
    stream = video_stream(source_probe)
    measured_duration = duration_seconds(source_probe)
    budget = compute_budget(measured_duration, cap_scale=args.cap_scale)
    encoder = detect_av1_encoder()
    source_width = int(stream["width"])
    source_height = int(stream["height"])

    log("encoding 16 kb/s audio")
    audio = encode_audio(source_segment, work / "audio.opus")
    log("decoding source metric proxy")
    source_frames = read_frames(source_segment, raw_path=work / "source-metric.raw")

    profile_widths = [384, 512, 640]
    baseline_trials: list[dict[str, Any]] = []
    best: tuple[float, float, dict[str, Any], dict[str, Any], list[np.ndarray]] | None = None
    for width in profile_widths:
        log(f"encoding all-structural profile width={width}")
        height = even(width * source_height / source_width)
        encoded = encode_to_target(
            source_segment,
            work / f"baseline-{width}x{height}.mkv",
            width=width,
            height=height,
            fps=METRIC_FPS,
            target_bytes=budget.all_structural_visual_bytes,
            encoder=encoder,
        )
        frames = read_frames(Path(encoded["path"]), raw_path=work / f"baseline-{width}-metric.raw")
        ref, cand = align(source_frames, frames)
        log(f"measuring all-structural profile width={width}")
        trial_metrics = metrics(ref, cand)
        record = {"encode": encoded, "metrics": trial_metrics}
        baseline_trials.append(record)
        key = (trial_metrics["mean_ssim"], trial_metrics["mean_psnr_db"])
        if best is None or key > best[:2]:
            best = (key[0], key[1], encoded, trial_metrics, cand)
        else:
            del cand
        gc.collect()
    assert best is not None
    _, _, baseline_encode, baseline_metrics, baseline_frames = best
    baseline_path = Path(baseline_encode["path"])

    # The atlas candidate uses the same winning operating point, with atlas bytes deducted.
    log("encoding atlas candidate structural stream")
    candidate_encode = encode_to_target(
        source_segment,
        work / "atlas-base.mkv",
        width=int(baseline_encode["width"]),
        height=int(baseline_encode["height"]),
        fps=float(baseline_encode["fps"]),
        target_bytes=budget.atlas_structural_bytes,
        encoder=encoder,
    )
    candidate_base_frames = read_frames(Path(candidate_encode["path"]), raw_path=work / "atlas-base-metric.raw")
    ref_frames, candidate_base_frames = align(source_frames, candidate_base_frames)
    log("building temporal residual atlas")
    atlas_info = build_atlas_adaptive(
        ref_frames,
        candidate_base_frames,
        work / "atlas",
        budget_bytes=budget.atlas_reserve_bytes,
    )
    log("applying temporal atlas pass 1")
    restored = apply_temporal_atlas(
        candidate_base_frames,
        work / "atlas" / "temporal-atlas.webp",
        work / "atlas" / "temporal-atlas.json",
        gain=0.90,
    )
    log("applying temporal atlas pass 2 for determinism")
    restored_second = apply_temporal_atlas(
        candidate_base_frames,
        work / "atlas" / "temporal-atlas.webp",
        work / "atlas" / "temporal-atlas.json",
        gain=0.90,
    )
    deterministic = frame_sequence_hash(restored) == frame_sequence_hash(restored_second)
    log("measuring restored candidate")
    atlas_metrics = metrics(ref_frames, restored)
    candidate_base_metrics = metrics(ref_frames, candidate_base_frames)
    del restored_second
    gc.collect()

    metadata = {
        "format": "GMP-100-GATE", "version": "1A", "duration_seconds": measured_duration,
        "source": {"url": SOURCE_URL, "attribution": SOURCE_ATTRIBUTION},
        "presentation": {"width": 3840, "height": 2160, "fps": 24000 / 1001, "target": "10-bit PQ in downstream gate"},
        "budget": budget.to_dict(),
    }
    baseline_package = package(
        out / "baseline-all-structural.gmp",
        base=baseline_path,
        audio=Path(audio["path"]),
        sidecars=[],
        metadata={**metadata, "candidate": "all-structural"},
        cap_bytes=budget.proxy_cap_bytes,
    )
    atlas_sidecars = [work / "atlas" / "temporal-atlas.webp", work / "atlas" / "temporal-atlas.json"]
    atlas_package = package(
        out / "candidate-temporal-atlas.gmp",
        base=Path(candidate_encode["path"]),
        audio=Path(audio["path"]),
        sidecars=atlas_sidecars,
        metadata={**metadata, "candidate": "structural-plus-temporal-atlas"},
        cap_bytes=budget.proxy_cap_bytes,
    )

    delta = {
        "mean_psnr_db": atlas_metrics["mean_psnr_db"] - baseline_metrics["mean_psnr_db"],
        "mean_ssim": atlas_metrics["mean_ssim"] - baseline_metrics["mean_ssim"],
        "p05_ssim": atlas_metrics["p05_ssim"] - baseline_metrics["p05_ssim"],
        "mean_edge_correlation": atlas_metrics["mean_edge_correlation"] - baseline_metrics["mean_edge_correlation"],
        "temporal_delta_mae": atlas_metrics["temporal_delta_mae"] - baseline_metrics["temporal_delta_mae"],
        "flow_delta": atlas_metrics["flow_delta"] - baseline_metrics["flow_delta"],
    }
    temporal_limit = baseline_metrics["temporal_delta_mae"] * 1.02 + 1e-6
    accepted = bool(
        atlas_package["cap_pass"]
        and baseline_package["cap_pass"]
        and atlas_package["payload_bytes"] <= baseline_package["payload_bytes"]
        and delta["mean_psnr_db"] > 0.0
        and delta["mean_ssim"] > 0.0
        and delta["p05_ssim"] >= -0.002
        and atlas_metrics["temporal_delta_mae"] <= temporal_limit
        and deterministic
    )

    log("writing visual evidence")
    write_contact_sheet(ref_frames, baseline_frames[:len(ref_frames)], restored, out / "contact-sheet.png")
    write_preview(ref_frames, baseline_frames[:len(ref_frames)], restored, out / "comparison-preview.mp4")

    result = {
        "status": "completed",
        "gate": "1A-photorealistic-1080p-SDR-proxy",
        "source": {
            "url": SOURCE_URL, "attribution": SOURCE_ATTRIBUTION,
            "segment_start_seconds": args.start, "requested_duration_seconds": args.duration,
            "measured_duration_seconds": measured_duration,
            "probe": source_probe,
        },
        "runtime": {
            "encoder": encoder,
            "wall_seconds": time.time() - started,
            "machine": os.uname()._asdict() if hasattr(os.uname(), "_asdict") else tuple(os.uname()),
        },
        "budget": budget.to_dict(),
        "audio": audio,
        "baseline": {
            "trials": baseline_trials,
            "winner_encode": baseline_encode,
            "metrics": baseline_metrics,
            "package": baseline_package,
        },
        "atlas_candidate": {
            "base_encode": candidate_encode,
            "base_metrics_before_atlas": candidate_base_metrics,
            "atlas": atlas_info,
            "metrics": atlas_metrics,
            "package": atlas_package,
            "deterministic": deterministic,
            "restored_sha256": frame_sequence_hash(restored),
        },
        "decision": {
            "accepted": accepted,
            "delta": delta,
            "rule": "retain only if equal-or-fewer payload bytes improve mean PSNR/SSIM without material tail or temporal regression and reproduce exactly",
            "next_action": "retain atlas for GPU temporal-model gate" if accepted else "return atlas allocation to structural AV1",
        },
        "unmeasured_required_gates": [
            "native 4K HDR/PQ behavior", "LPIPS/DISTS", "face identity drift", "articulated topology drift",
            "OCR accuracy", "blind human preference", "GPU temporal-restoration model",
        ],
    }
    write_json(out / "gate-results.json", result)
    (out / "gate-report.md").write_text(report_markdown(result))
    (out / "SOURCE_LICENSE.md").write_text(
        f"# Source and Attribution\n\n{SOURCE_ATTRIBUTION}\n\nSource: {SOURCE_URL}\n\n"
        "This benchmark artifact contains only a bounded excerpt and derived comparison material for codec research.\n"
    )
    shutil.rmtree(work, ignore_errors=True)
    print(json.dumps({
        "accepted": accepted,
        "baseline_mean_ssim": baseline_metrics["mean_ssim"],
        "atlas_mean_ssim": atlas_metrics["mean_ssim"],
        "delta_mean_ssim": delta["mean_ssim"],
        "baseline_package_bytes": baseline_package["bytes"],
        "atlas_package_bytes": atlas_package["bytes"],
        "result": str(out / "gate-results.json"),
    }, indent=2))
    return 0 if accepted else 3


if __name__ == "__main__":
    raise SystemExit(main())
