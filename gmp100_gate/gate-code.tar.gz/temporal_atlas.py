from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Sequence

import cv2
import numpy as np


class AtlasError(RuntimeError):
    pass


@dataclasses.dataclass
class AtlasManifest:
    version: str
    frame_count: int
    width: int
    height: int
    map_width: int
    map_height: int
    quantization_step: float
    residual_clip: float
    grid_columns: int
    grid_rows: int
    anchor_frames: list[int]
    temporal_radius: int
    webp_quality: int
    atlas_bytes: int
    atlas_sha256: str

    def as_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def luma(frame: np.ndarray) -> np.ndarray:
    if frame.ndim == 2:
        return frame.astype(np.uint8, copy=False)
    return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


def residual_score(source: np.ndarray, base: np.ndarray) -> float:
    src = luma(source).astype(np.float32)
    low = luma(base).astype(np.float32)
    src_small = cv2.resize(src, (max(64, src.shape[1] // 2), max(36, src.shape[0] // 2)), interpolation=cv2.INTER_AREA)
    low_small = cv2.resize(low, (src_small.shape[1], src_small.shape[0]), interpolation=cv2.INTER_AREA)
    absolute = np.mean(np.abs(src_small - low_small))
    edge = np.mean(
        np.abs(
            cv2.Laplacian(src_small, cv2.CV_32F)
            - cv2.Laplacian(low_small, cv2.CV_32F)
        )
    )
    return float(absolute + 0.25 * edge)


def select_anchors(
    source_frames: Sequence[np.ndarray],
    base_frames: Sequence[np.ndarray],
    *,
    anchor_count: int,
) -> list[int]:
    if len(source_frames) != len(base_frames):
        raise AtlasError("source and base frame counts differ")
    if len(source_frames) == 0:
        raise AtlasError("empty frame sequence")
    anchor_count = max(1, min(anchor_count, len(source_frames)))
    scores = [residual_score(src, base) for src, base in zip(source_frames, base_frames)]

    # Divide the timeline into bins, then select the highest-value frame in each bin.
    # This prevents every anchor from collapsing into one difficult instant.
    boundaries = np.linspace(0, len(scores), anchor_count + 1, dtype=int)
    anchors: list[int] = []
    for start, end in zip(boundaries[:-1], boundaries[1:]):
        end = max(end, start + 1)
        local = int(np.argmax(scores[start:end]))
        anchors.append(int(start + local))
    return sorted(set(anchors))


def _build_atlas(
    maps: Sequence[np.ndarray],
    map_width: int,
    map_height: int,
) -> tuple[np.ndarray, int, int]:
    columns = max(1, math.ceil(math.sqrt(len(maps))))
    rows = math.ceil(len(maps) / columns)
    atlas = np.full((rows * map_height, columns * map_width), 128, np.uint8)
    for index, residual in enumerate(maps):
        x = (index % columns) * map_width
        y = (index // columns) * map_height
        atlas[y : y + map_height, x : x + map_width] = residual
    return atlas, columns, rows


def encode_temporal_atlas(
    source_frames: Sequence[np.ndarray],
    base_frames: Sequence[np.ndarray],
    output_dir: Path,
    *,
    budget_bytes: int,
    anchor_count: int = 8,
    map_width: int | None = None,
    map_height: int | None = None,
    quantization_step: float = 1.0,
    residual_clip: float = 64.0,
    temporal_radius: int = 12,
) -> AtlasManifest:
    if budget_bytes <= 0:
        raise AtlasError("budget_bytes must be positive")
    if len(source_frames) != len(base_frames) or len(source_frames) == 0:
        raise AtlasError("source/base sequences must be non-empty and equal length")

    height, width = source_frames[0].shape[:2]
    if any(frame.shape[:2] != (height, width) for frame in source_frames):
        raise AtlasError("source frame dimensions are not uniform")
    if any(frame.shape[:2] != (height, width) for frame in base_frames):
        raise AtlasError("base frame dimensions are not uniform")

    map_width = map_width or max(96, width // 2)
    map_height = map_height or max(54, height // 2)
    anchors = select_anchors(source_frames, base_frames, anchor_count=anchor_count)

    maps: list[np.ndarray] = []
    for frame_index in anchors:
        src_y = luma(source_frames[frame_index]).astype(np.float32)
        base_y = luma(base_frames[frame_index]).astype(np.float32)
        residual = np.clip(src_y - base_y, -residual_clip, residual_clip)
        residual = cv2.resize(
            residual,
            (map_width, map_height),
            interpolation=cv2.INTER_AREA,
        )
        quantized = np.clip(
            np.rint(residual / quantization_step) + 128.0,
            0,
            255,
        ).astype(np.uint8)
        maps.append(quantized)

    atlas, columns, rows = _build_atlas(maps, map_width, map_height)
    output_dir.mkdir(parents=True, exist_ok=True)
    atlas_path = output_dir / "temporal-atlas.webp"

    selected_quality: int | None = None
    for quality in range(100, 4, -5):
        if not cv2.imwrite(
            str(atlas_path),
            atlas,
            [cv2.IMWRITE_WEBP_QUALITY, quality],
        ):
            raise AtlasError("OpenCV failed to encode WebP atlas")
        if atlas_path.stat().st_size <= budget_bytes:
            selected_quality = quality
            break
    if selected_quality is None:
        raise AtlasError(
            f"atlas cannot fit {budget_bytes:,} bytes even at minimum quality"
        )

    manifest = AtlasManifest(
        version="1.0",
        frame_count=len(source_frames),
        width=width,
        height=height,
        map_width=map_width,
        map_height=map_height,
        quantization_step=quantization_step,
        residual_clip=residual_clip,
        grid_columns=columns,
        grid_rows=rows,
        anchor_frames=anchors,
        temporal_radius=temporal_radius,
        webp_quality=selected_quality,
        atlas_bytes=atlas_path.stat().st_size,
        atlas_sha256=sha256(atlas_path),
    )
    (output_dir / "temporal-atlas.json").write_text(
        json.dumps(manifest.as_dict(), indent=2) + "\n"
    )
    return manifest


def read_manifest(path: Path) -> AtlasManifest:
    payload = json.loads(path.read_text())
    return AtlasManifest(**payload)


def decode_maps(atlas_path: Path, manifest: AtlasManifest) -> list[np.ndarray]:
    if sha256(atlas_path) != manifest.atlas_sha256:
        raise AtlasError("atlas checksum mismatch")
    atlas = cv2.imread(str(atlas_path), cv2.IMREAD_GRAYSCALE)
    if atlas is None:
        raise AtlasError("failed to decode atlas")
    result: list[np.ndarray] = []
    for index in range(len(manifest.anchor_frames)):
        x = (index % manifest.grid_columns) * manifest.map_width
        y = (index // manifest.grid_columns) * manifest.map_height
        quantized = atlas[
            y : y + manifest.map_height,
            x : x + manifest.map_width,
        ]
        result.append(
            (quantized.astype(np.float32) - 128.0)
            * manifest.quantization_step
        )
    return result


def _warp_anchor_to_target(
    target_y: np.ndarray,
    anchor_y: np.ndarray,
    residual_map: np.ndarray,
    *,
    temporal_weight: float,
) -> tuple[np.ndarray, np.ndarray]:
    flow_width = residual_map.shape[1]
    flow_height = residual_map.shape[0]
    target_small = cv2.resize(
        target_y,
        (flow_width, flow_height),
        interpolation=cv2.INTER_AREA,
    )
    anchor_small = cv2.resize(
        anchor_y,
        (flow_width, flow_height),
        interpolation=cv2.INTER_AREA,
    )

    # Compute target→anchor correspondence so remap can sample the anchor residual.
    flow = cv2.calcOpticalFlowFarneback(
        target_small,
        anchor_small,
        None,
        0.5,
        3,
        19,
        3,
        5,
        1.2,
        0,
    )
    grid_x, grid_y = np.meshgrid(
        np.arange(flow_width, dtype=np.float32),
        np.arange(flow_height, dtype=np.float32),
    )
    map_x = grid_x + flow[..., 0]
    map_y = grid_y + flow[..., 1]
    warped_residual = cv2.remap(
        residual_map,
        map_x,
        map_y,
        cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REFLECT101,
    )
    predicted_target = cv2.remap(
        anchor_small,
        map_x,
        map_y,
        cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT101,
    )
    confidence = np.exp(
        -np.abs(
            predicted_target.astype(np.float32)
            - target_small.astype(np.float32)
        )
        / 16.0
    )
    magnitude = np.clip((np.abs(warped_residual) - 0.5) / 8.0, 0.0, 1.0)
    weight = confidence * magnitude * temporal_weight
    return warped_residual, weight


def apply_temporal_atlas(
    base_frames: Sequence[np.ndarray],
    atlas_path: Path,
    manifest_path: Path,
    *,
    gain: float = 0.90,
) -> list[np.ndarray]:
    manifest = read_manifest(manifest_path)
    if len(base_frames) != manifest.frame_count:
        raise AtlasError(
            f"expected {manifest.frame_count} base frames, got {len(base_frames)}"
        )
    maps = decode_maps(atlas_path, manifest)
    anchor_y = {
        frame_index: luma(base_frames[frame_index])
        for frame_index in manifest.anchor_frames
    }
    map_by_frame = {
        frame_index: maps[index]
        for index, frame_index in enumerate(manifest.anchor_frames)
    }
    restored: list[np.ndarray] = []

    for frame_index, frame in enumerate(base_frames):
        ycc = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        target_y = ycc[:, :, 0].astype(np.float32)
        accumulator = np.zeros((manifest.map_height, manifest.map_width), np.float32)
        weight_sum = np.zeros_like(accumulator)

        for anchor_index in manifest.anchor_frames:
            distance = abs(frame_index - anchor_index)
            if distance > manifest.temporal_radius:
                continue
            residual = map_by_frame[anchor_index]
            if distance == 0:
                warped = residual
                weight = np.clip((np.abs(warped) - 0.25) / 6.0, 0.0, 1.0)
            else:
                temporal_weight = math.exp(
                    -((distance / max(manifest.temporal_radius * 0.70, 1.0)) ** 2)
                )
                warped, weight = _warp_anchor_to_target(
                    target_y.astype(np.uint8),
                    anchor_y[anchor_index],
                    residual,
                    temporal_weight=temporal_weight,
                )
            accumulator += warped * weight
            weight_sum += weight

        correction_small = np.divide(
            accumulator,
            np.maximum(weight_sum, 1e-6),
            out=np.zeros_like(accumulator),
            where=weight_sum > 1e-6,
        )
        correction = cv2.resize(
            correction_small,
            (manifest.width, manifest.height),
            interpolation=cv2.INTER_CUBIC,
        )
        reliability = cv2.resize(
            np.clip(weight_sum, 0.0, 1.0),
            (manifest.width, manifest.height),
            interpolation=cv2.INTER_LINEAR,
        )
        corrected_y = np.clip(
            target_y + gain * correction * reliability,
            0,
            255,
        ).astype(np.uint8)
        output = ycc.copy()
        output[:, :, 0] = corrected_y
        restored.append(cv2.cvtColor(output, cv2.COLOR_YCrCb2BGR))
    return restored


def frame_sequence_hash(frames: Sequence[np.ndarray]) -> str:
    digest = hashlib.sha256()
    for frame in frames:
        digest.update(np.ascontiguousarray(frame).tobytes())
    return digest.hexdigest()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Deterministic optical-flow temporal detail atlas"
    )
    parser.add_argument(
        "--about",
        action="store_true",
        help="print the sidecar contract and exit",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.about:
        print(
            "Temporal atlas: sparse source residual anchors, WebP atlas, "
            "target-to-anchor optical-flow propagation, deterministic luma compositing."
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
